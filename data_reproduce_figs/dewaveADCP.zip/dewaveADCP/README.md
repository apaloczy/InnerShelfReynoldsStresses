# dewaveADCP
Remove surface gravity wave signal from ADCP velocity data in along-beam coordinates.
